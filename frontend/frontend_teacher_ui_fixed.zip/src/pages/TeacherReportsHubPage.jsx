import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../lib/api.js";
import InfoBox from "../components/InfoBox.jsx";

export default function TeacherReportsHubPage() {
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await api.listSubjects();
        if (mounted) setSubjects(Array.isArray(data) ? data : []);
      } catch (e) {
        if (mounted) setError(e?.message || "Failed to load subjects");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div>
        <h2 style={{ margin: 0 }}>Reports</h2>
        <div style={{ color: "rgba(255,255,255,.7)", marginTop: 6 }}>
          Pick a subject to view aggregated performance (attempts, accuracy, unique students).
        </div>
      </div>

      <InfoBox title="What you can see here">
        <div>• Total attempts and average accuracy for the subject.</div>
        <div>• Unique students who attempted questions.</div>
        <div>• Per-module breakdown inside each subject report.</div>
      </InfoBox>

      {loading && <div className="card">Loading…</div>}
      {error && (
        <div className="card" style={{ border: "1px solid rgba(255,80,80,.35)" }}>
          {error}
        </div>
      )}

      {!loading && !error && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 12 }}>
          {subjects.map((s) => (
            <div key={s.id} className="card" style={{ display: "grid", gap: 10 }}>
              <div style={{ fontWeight: 900, fontSize: 16 }}>{s.name}</div>
              {s.description && (
                <div style={{ color: "rgba(255,255,255,.7)", fontSize: 13 }}>{s.description}</div>
              )}

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                <Link className="btn btn-primary" to={`/t/subject/${s.id}/stats`}>
                  Open stats
                </Link>
                <Link className="btn" to={`/t/subject/${s.id}`}>
                  Open subject
                </Link>
              </div>
            </div>
          ))}

          {subjects.length === 0 && <div className="card">No subjects yet.</div>}
        </div>
      )}
    </div>
  );
}
